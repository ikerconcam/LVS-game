#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <Windows.h>
#include <mmsystem.h>
#pragma comment(lib, "Winmm.lib")

using namespace std;

struct Combatiente {
    string nombre;
    int puntos;
};

struct Combate {
    Combatiente combatiente1;
    Combatiente combatiente2;
};

void simular_combate(Combate& combate, const string& apuesta) {
    srand(time(0));
    for (int i = 0; i < 5; ++i) {
        cout << "Round " << i + 1 << "\n";
        int resultado = rand() % 3;
        if (resultado == 0) {
            combate.combatiente1.puntos++;
            cout << combate.combatiente1.nombre << " parece estar un poco mejor en este round.\n";
        }
        else if (resultado == 1) {
            combate.combatiente2.puntos++;
            cout << combate.combatiente2.nombre << " parece estar un poco mejor en este round.\n";
        }
        else {
            cout << "Parece que este round ha sido bastante igualado.\n";
        }
        cout << "Listo para el siguiente round?\n";
        string respuesta;
        cin >> respuesta;
        while (respuesta != "Si" && respuesta != "si") {
            cout << "Vaya... y ahora? (Si)\n";
            cin >> respuesta;
        }
        if (respuesta == "No" || respuesta == "no") {
            cout << "El combate se ha detenido.\n";
            return;
        }
        if (rand() % 100 < 5) { // 5% KO
            cout << "KO! " << combate.combatiente1.nombre << " ha ganado el combate.\n";
            if (combate.combatiente1.nombre == apuesta) {
                cout << "Has ganado la apuesta!\n";
            }
            else {
                cout << "Has perdido la apuesta.\n";
            }
            return;
        }
        if (rand() % 100 < 5) { // 5% KO
            cout << "KO! " << combate.combatiente2.nombre << " ha ganado el combate.\n";
            if (combate.combatiente2.nombre == apuesta) {
                cout << "Has ganado la apuesta!\n";
            }
            else {
                cout << "Has perdido la apuesta.\n";
            }
            return;
        }
        if (rand() % 100 < 5) { // 5% lesion
            cout << "Lesión! " << combate.combatiente1.nombre << " se ha lesionado. " << combate.combatiente2.nombre << " ha ganado el combate.\n";
            if (combate.combatiente2.nombre == apuesta) {
                cout << "Has ganado la apuesta!\n";
            }
            else {
                cout << "Has perdido la apuesta.\n";
            }
            return;
        }
        if (rand() % 100 < 5) { // 5% lesion
            cout << "Lesión! " << combate.combatiente2.nombre << " se ha lesionado. " << combate.combatiente1.nombre << " ha ganado el combate.\n";
            if (combate.combatiente1.nombre == apuesta) {
                cout << "¡Has ganado la apuesta!\n";
            }
            else {
                cout << "Has perdido la apuesta.\n";
            }
            return;
        }
    }
    if (combate.combatiente1.puntos > combate.combatiente2.puntos) {
        cout << "El ganador es " << combate.combatiente1.nombre << ".\n";
        if (combate.combatiente1.nombre == apuesta) {
            cout << "Has ganado la apuesta!\n";
        }
        else {
            cout << "Has perdido la apuesta.\n";
        }
    }
    else if (combate.combatiente1.puntos < combate.combatiente2.puntos) {
        cout << "El ganador es " << combate.combatiente2.nombre << ".\n";
        if (combate.combatiente2.nombre == apuesta) {
            cout << "Has ganado la apuesta!\n";
        }
        else {
            cout << "Has perdido la apuesta.\n";
        }
    }
    else {
        cout << "El combate ha terminado en empate.\n";
        cout << "Has perdido la apuesta.\n";
    }
}

int main() {

    // Abre el archivo MP3
    mciSendString(L"open \"musica/combate.mp3\" type mpegvideo alias mp3", NULL, 0, NULL);

    // Reproduce el archivo MP3 en un bucle infinito
    mciSendString(L"play mp3 repeat", NULL, 0, NULL);

    cout << "Bienvendio/a al juego oficial de La Velada de la Sagrera LVS Game! Esperamos que disfrutes este juego que simula los combates la la LVS real donde puedes escoger a tu peleador favorito y apostar por el. Tendras suerte y ganaras? Averigualo:\n";

    vector<Combate> combates = {
        {{"Quim", 0}, {"Quintanilla", 0}},
        {{"Eric", 0}, {"Mur", 0}},
        {{"Julia", 0}, {"Laura", 0}},
        {{"Carlos", 0}, {"Angel", 0}},
        {{"Iker", 0}, {"Biel", 0}},
        {{"Fabregat", 0}, {"John", 0}}
    };

    vector<string> nombres_combates = { "primer", "segundo", "tercer", "cuarto", "quinto", "sexto" };

    for (int i = 0; i < combates.size(); ++i) {
        auto& combate = combates[i];
        cout << "Empieza el " << nombres_combates[i] << " combate, en una esquina encontramos a " << combate.combatiente1.nombre << " y por la otra tenemos a " << combate.combatiente2.nombre << ".\n";
        cout << "Quien crees que va a ganar?\n";
        string apuesta;
        cin >> apuesta;
        while (apuesta != combate.combatiente1.nombre && apuesta != combate.combatiente2.nombre) {
            cout << "No coincide con ningun peleador. ¿Quien crees que va a ganar?\n";
            cin >> apuesta;
        }
        cout << "Cuanto dinero quieres apostar?\n";
        int cantidad;
        cin >> cantidad;
        while (cantidad <= 0) {
            cout << "La apuesta a de ser sin centimos Ej: 100\n";
            cin >> cantidad;
        }
        cout << "Pues a ver si hay suerte...\n";
        simular_combate(combate, apuesta);
    }

    return 0;
}
